from datetime import datetime

from sqlalchemy import text
from sqlalchemy.orm import Session

from app.models.support_attachment import SupportAttachment
from app.models.support_request import SupportRequest


class SupportRepository:
    def _generate_support_request_id(self, db: Session) -> str:
        sql = text("""
            DECLARE @NewID VARCHAR(17);
            EXEC dbo.sp_GenerateSupportRequestID @NewID=@NewID OUTPUT;
            SELECT @NewID AS NewID;
        """)
        row = db.execute(sql).mappings().first()
        return row["NewID"]

    def create_request(self, db: Session, payload: dict, user_id: str) -> SupportRequest:
        new_id = self._generate_support_request_id(db)
        item = SupportRequest(
            SupportRequestID=new_id,
            UserID=user_id,
            Subject=payload["subject"].strip(),
            Message=payload["message"].strip(),
            SupportType=payload["support_type"],
            Priority=payload.get("priority", "medium"),
            Status="pending",
        )
        db.add(item)
        db.commit()
        db.refresh(item)
        return item

    def add_attachments(self, db: Session, support_request_id: str, attachments: list[dict]) -> list[SupportAttachment]:
        output = []
        for attachment in attachments:
            entity = SupportAttachment(
                SupportRequestID=support_request_id,
                FileName=attachment["file_name"],
                FileUrl=attachment["file_url"],
                FileType=attachment.get("file_type"),
                FileSize=attachment.get("file_size"),
            )
            db.add(entity)
            output.append(entity)
        db.commit()
        return output

    def get_by_id(self, db: Session, support_request_id: str) -> SupportRequest | None:
        return (
            db.query(SupportRequest)
            .filter(SupportRequest.SupportRequestID == support_request_id)
            .first()
        )

    def get_user_request(self, db: Session, support_request_id: str, user_id: str) -> SupportRequest | None:
        return (
            db.query(SupportRequest)
            .filter(
                SupportRequest.SupportRequestID == support_request_id,
                SupportRequest.UserID == user_id,
            )
            .first()
        )

    def list_by_user(self, db: Session, user_id: str) -> list[SupportRequest]:
        return (
            db.query(SupportRequest)
            .filter(SupportRequest.UserID == user_id)
            .order_by(SupportRequest.CreatedAt.desc())
            .all()
        )

    def list_for_admin(
        self,
        db: Session,
        status: str | None = None,
        support_type: str | None = None,
        priority: str | None = None,
    ) -> list[SupportRequest]:
        query = db.query(SupportRequest)

        if status:
            query = query.filter(SupportRequest.Status == status)
        if support_type:
            query = query.filter(SupportRequest.SupportType == support_type)
        if priority:
            query = query.filter(SupportRequest.Priority == priority)

        return query.order_by(SupportRequest.CreatedAt.desc()).all()

    def list_attachments(self, db: Session, support_request_id: str) -> list[SupportAttachment]:
        return (
            db.query(SupportAttachment)
            .filter(SupportAttachment.SupportRequestID == support_request_id)
            .order_by(SupportAttachment.CreatedAt.asc(), SupportAttachment.AttachmentID.asc())
            .all()
        )

    def mark_viewed(self, db: Session, item: SupportRequest) -> SupportRequest:
        if item.Status == "pending":
            item.Status = "viewed"
        if item.ViewedAt is None:
            item.ViewedAt = datetime.now()
        item.UpdatedAt = datetime.now()
        db.commit()
        db.refresh(item)
        return item

    def reply(self, db: Session, item: SupportRequest, reply_text: str) -> SupportRequest:
        now = datetime.now()
        item.AdminReply = reply_text.strip()
        item.Status = "replied"
        if item.ViewedAt is None:
            item.ViewedAt = now
        item.RepliedAt = now
        item.UpdatedAt = now
        db.commit()
        db.refresh(item)
        return item

    def close(self, db: Session, item: SupportRequest) -> SupportRequest:
        now = datetime.now()
        item.Status = "closed"
        if item.ViewedAt is None:
            item.ViewedAt = now
        item.ClosedAt = now
        item.UpdatedAt = now
        db.commit()
        db.refresh(item)
        return item
