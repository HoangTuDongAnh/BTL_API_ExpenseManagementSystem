﻿namespace ExpenseWeb.Models.ViewModels.Auth
{
    public class VerifyOtpViewModel
    {
        public string Email { get; set; }
        public string Otp { get; set; }
    }
}
