﻿namespace ExpenseWeb.Models.Dtos.Auth
{
    public class LoginRequestDto
    {
        public string email { get; set; }
        public string password { get; set; }
    }
}