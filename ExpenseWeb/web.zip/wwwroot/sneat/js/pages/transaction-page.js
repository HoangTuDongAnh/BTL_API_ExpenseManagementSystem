﻿document.addEventListener('DOMContentLoaded', () => {
  const lang = (window.transactionPageLang || 'vi').toLowerCase();
  const locale = lang === 'en' ? 'en-US' : 'vi-VN';
  const t = (vi, en) => (lang === 'en' ? en : vi);
  const qs = (id) => document.getElementById(id);
  const transactions = JSON.parse(qs('tx-transactions-json')?.textContent || '[]');
  const categories = JSON.parse(qs('tx-categories-json')?.textContent || '[]');
  const wallets = JSON.parse(qs('tx-wallets-json')?.textContent || '[]');

  const state = {
    type: 'all',
    walletId: 'all',
    keyword: '',
    period: 'today',
    from: null,
    to: null,
    currentDay: startOfDay(findLatestDate(transactions) || new Date()),
    currentMonth: monthStart(findLatestDate(transactions) || new Date()),
    filtered: [],
    currentPage: 1,
    pageSize: 6,
    charts: { income: null, expense: null },
    detailId: null
  };

  const addModalEl = qs('addTransactionModal');
  const detailModalEl = qs('transactionDetailModal');
  const dayOffcanvasEl = qs('transactionDayOffcanvas');
  const addModal = addModalEl ? bootstrap.Modal.getOrCreateInstance(addModalEl) : null;
  const detailModal = detailModalEl ? bootstrap.Modal.getOrCreateInstance(detailModalEl) : null;
  const dayOffcanvas = dayOffcanvasEl ? bootstrap.Offcanvas.getOrCreateInstance(dayOffcanvasEl) : null;

  const fpConfigBase = {
    altInput: true,
    altFormat: 'd/m/Y',
    dateFormat: 'Y-m-d',
    locale: lang === 'en' ? 'default' : flatpickr.l10ns.vn
  };
  const fromFp = qs('fromDateFilter') ? flatpickr(qs('fromDateFilter'), fpConfigBase) : null;
  const toFp = qs('toDateFilter') ? flatpickr(qs('toDateFilter'), fpConfigBase) : null;
  const addDateFp = qs('addTransactionDate') ? flatpickr(qs('addTransactionDate'), { ...fpConfigBase, defaultDate: state.currentDay }) : null;
  const detailDateFp = qs('detailEditDate') ? flatpickr(qs('detailEditDate'), fpConfigBase) : null;

  function startOfDay(d){ const x = new Date(d); x.setHours(0,0,0,0); return x; }
  function monthStart(d){ const x = startOfDay(d); x.setDate(1); return x; }
  function iso(d){ return startOfDay(d).toISOString().slice(0,10); }
  function parseISO(s){ return s ? startOfDay(new Date(s+'T00:00:00')) : null; }
  function fmtDate(d){ return d.toLocaleDateString(locale,{day:'2-digit',month:'2-digit',year:'numeric'}); }
  function fmtLong(d){ return d.toLocaleDateString(locale,{weekday:'short',day:'2-digit',month:'2-digit',year:'numeric'}); }
  function fmtMonth(d){ return d.toLocaleDateString(locale,{month:'long',year:'numeric'}); }
  function fmtMoney(v){ return Number(v||0).toLocaleString(locale)+' VND'; }
  function fmtPct(v){ return Number(v||0).toFixed(1).replace('.0','')+'%'; }
  function findLatestDate(list){ if(!list.length) return null; return list.map(x=>parseISO(x.transactionDate)).sort((a,b)=>b-a)[0]; }
  function escapeHtml(v){ return String(v ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }
  function isImageIcon(icon){ return !!icon && (icon.includes('/') || /\.(svg|png|webp|jpe?g)$/i.test(icon)); }
  function iconMarkup(icon, alt, cls=''){ return isImageIcon(icon) ? `<img src="${escapeHtml(icon)}" alt="${escapeHtml(alt||'icon')}" class="tx-inline-icon ${cls}" />` : `<i class="${escapeHtml(icon || 'bx bx-category')} ${cls}"></i>`; }
  function colorAlpha(hex, alpha){ if(!hex || !hex.startsWith('#')) return `rgba(105,108,255,${alpha})`; const clean = hex.length===4 ? '#'+hex[1]+hex[1]+hex[2]+hex[2]+hex[3]+hex[3] : hex; const n = parseInt(clean.slice(1),16); return `rgba(${(n>>16)&255},${(n>>8)&255},${n&255},${alpha})`; }
  function categoryInfo(id){ return categories.find(x => x.category_id === id) || null; }
  function walletInfo(id){ return wallets.find(x => x.wallet_id === id) || null; }
  function daySet(list){ return [...new Set(list.map(x=>x.transactionDate))].sort(); }

  function baseFilteredTransactions(){
    return transactions.filter(tx => {
      if(state.type !== 'all' && tx.transactionType !== state.type) return false;
      if(state.walletId !== 'all' && tx.walletId !== state.walletId) return false;
      if(state.keyword){
        const hay = `${tx.note} ${tx.categoryName} ${tx.walletName}`.toLowerCase();
        if(!hay.includes(state.keyword)) return false;
      }
      return true;
    });
  }

  function applyPeriodFilter(list){
    const from = state.from ? parseISO(state.from) : null;
    const to = state.to ? parseISO(state.to) : null;
    const baseDay = state.currentDay;
    return list.filter(tx => {
      const d = parseISO(tx.transactionDate);
      if(state.period === 'today' && iso(d) !== iso(baseDay)) return false;
      if(state.period === 'week') {
        const s = startOfDay(new Date(baseDay));
        s.setDate(s.getDate()-6);
        if(d < s || d > baseDay) return false;
      }
      if(state.period === 'month') {
        if(d.getFullYear() !== baseDay.getFullYear() || d.getMonth() !== baseDay.getMonth()) return false;
      }
      if(state.period === 'custom') {
        if(from && d < from) return false;
        if(to && d > to) return false;
      }
      return true;
    }).sort((a,b)=> (b.transactionDate+b.id).localeCompare(a.transactionDate+a.id));
  }

  function applyFilters(){
    state.filtered = applyPeriodFilter(baseFilteredTransactions());
    state.currentPage = 1;
  }

  function renderLegends(target, groups){
    if(!target) return;
    if(!groups.length){
      target.innerHTML = `<div class="tx-summary-empty">${t('Chưa có dữ liệu phù hợp.','No matching data.')}</div>`;
      return;
    }
    const total = groups.reduce((s,g)=>s+g.value,0);
    target.innerHTML = groups.map(g => `
      <div class="tx-summary-item">
        <div class="tx-summary-item-left">
          <span class="tx-summary-dot" style="background:${g.color}"></span>
          <span class="tx-summary-name">${escapeHtml(g.name)}</span>
        </div>
        <div class="tx-summary-item-right">
          <strong>${fmtMoney(g.value)}</strong>
          <span>${fmtPct((g.value/total)*100)}</span>
        </div>
      </div>
    `).join('');
  }

  function makeGroups(type){
    const grouped = new Map();
    state.filtered.filter(x=>x.transactionType===type).forEach(tx => {
      const key = tx.categoryId || tx.categoryName;
      if(!grouped.has(key)) grouped.set(key,{ name: tx.categoryName, value:0, color: tx.categoryColor || '#8592A3'});
      grouped.get(key).value += Number(tx.amountValue||0);
    });
    return [...grouped.values()].sort((a,b)=>b.value-a.value).slice(0,5);
  }

  function ensureChart(kind, canvasId, totalId, legendId){
    const canvas = qs(canvasId);
    const groups = makeGroups(kind);
    qs(totalId).textContent = fmtMoney(groups.reduce((s,g)=>s+g.value,0));
    renderLegends(qs(legendId), groups);

    if(state.charts[kind]) state.charts[kind].destroy();

    state.charts[kind] = new Chart(canvas, {
      type:'doughnut',
      data:{
        labels: groups.map(g=>g.name),
        datasets:[{
          data: groups.map(g=>g.value),
          backgroundColor: groups.map(g=>g.color),
          borderColor:'#fff',
          borderWidth:4,
          hoverOffset:6
        }]
      },
      options:{
        responsive:true,
        maintainAspectRatio:false,
        cutout:'66%',
        plugins:{
          legend:{display:false},
          tooltip:{
            callbacks:{
              label:(ctx)=> `${ctx.label}: ${fmtMoney(ctx.raw)}`
            }
          }
        }
      }
    });
  }

  function renderList(){
    const shell = qs('transactionListShell');
    const empty = qs('transactionEmptyState');
    const badge = qs('transactionCountBadge');

    badge.textContent = `${state.filtered.length} ${t('giao dịch','transactions')}`;

    if(!state.filtered.length){
      shell.innerHTML='';
      empty.classList.remove('d-none');
      qs('transactionPagination').innerHTML='';
      return;
    }

    empty.classList.add('d-none');

    const start = (state.currentPage-1)*state.pageSize;
    const pageItems = state.filtered.slice(start, start+state.pageSize);

    shell.innerHTML = pageItems.map(tx => {
      const amountClass = tx.transactionType === 'income' ? 'income':'expense';
      return `
        <div class="tx-row-card">
          <div class="tx-main">
            <div class="tx-main-icon" style="background:${colorAlpha(tx.categoryColor,.15)};color:${tx.categoryColor}">
              ${iconMarkup(tx.categoryIcon, tx.categoryName)}
            </div>
            <div>
              <h6>${escapeHtml(tx.note)}</h6>
              <p>${escapeHtml(tx.recurringBadgeText)}</p>
            </div>
          </div>
          <div>
            <span class="tx-pill" style="background:${colorAlpha(tx.categoryColor,.12)};color:${tx.categoryColor}">
              ${iconMarkup(tx.categoryIcon, tx.categoryName,'tx-inline-icon-sm')}
              ${escapeHtml(tx.categoryName)}
            </span>
          </div>
          <div class="tx-meta-col">
            <span>${escapeHtml(tx.walletName)}</span>
          </div>
          <div class="tx-meta-col">
            <span>${escapeHtml(tx.transactionDateText)}</span>
            <small>${escapeHtml(tx.currency)}</small>
          </div>
          <div class="tx-amount ${amountClass}">${escapeHtml(tx.amountText)}</div>
          <div class="tx-actions">
            <button class="tx-action-btn view" data-action="view" data-id="${tx.id}" title="${t('Xem chi tiết','View')}">
              <i class="bx bx-show"></i>
            </button>
            <button class="tx-action-btn delete" data-action="delete" data-id="${tx.id}" title="${t('Xóa','Delete')}">
              <i class="bx bx-trash"></i>
            </button>
          </div>
        </div>
      `;
    }).join('');

    renderPagination();
  }

  function renderPagination(){
    const totalPages = Math.max(1, Math.ceil(state.filtered.length/state.pageSize));
    const wrap = qs('transactionPagination');
    if(totalPages <= 1){
      wrap.innerHTML='';
      return;
    }
    let html='';
    for(let p=1;p<=totalPages;p++){
      html += `<button type="button" class="${p===state.currentPage?'active':''}" data-page="${p}">${p}</button>`;
    }
    wrap.innerHTML = html;
  }

  function calendarTxForMonth(){
    const month = state.currentMonth.getMonth();
    const year = state.currentMonth.getFullYear();
    return baseFilteredTransactions().filter(tx => {
      const d = parseISO(tx.transactionDate);
      return d.getMonth()===month && d.getFullYear()===year;
    });
  }

  function renderCalendar(){
    qs('calendarTitle').textContent = fmtMonth(state.currentMonth);

    const monthTx = calendarTxForMonth();
    const map = new Map();

    monthTx.forEach(tx => {
      if(!map.has(tx.transactionDate)) map.set(tx.transactionDate, []);
      map.get(tx.transactionDate).push(tx);
    });

    const first = monthStart(state.currentMonth);
    const gridStart = new Date(first);
    gridStart.setDate(first.getDate()-first.getDay());

    let html='';

    for(let i=0;i<42;i++) {
    const d = new Date(gridStart);
    d .setDate(gridStart.getDate()+i);
    const key = iso(d);
    const items = map.get(key) || [];
    const income = items.filter(x=>x.transactionType==='income').reduce((s,x)=>s+Number(x.amountValue),0);
    const expense = items.filter(x=>x.transactionType==='expense').reduce((s,x)=>s+Number(x.amountValue),0);
    const level = items.length >=4 ? 4 : items.length===3 ? 3 : items.length===2 ? 2 : 1;
    const dotClass = income && expense ? 'mix' : income ? 'income' : expense ? 'expense' : '';
    const amountLabel = expense ? `-$

{
    Number(expense).toLocaleString(locale)
}

` : income ? ` + $ {
    Number(income).toLocaleString(locale)
}

` : '';

html + = `
<button type="button" class="tx-day-cell ${d.getMonth()!==state.currentMonth.getMonth()?'other':''} ${key===iso(new Date())?'today':''} level-${level}" data-date="${key}" >
<div class="tx-day-top" >
<span class="tx-day-num" > $ {
    d .getDate()
}

</span >
$ {
    items .length ? `<span class="tx-day-badge">$

{
    items .length
}

</span > ` : ''
}

</div >
<div class="tx-day-body ${items.length?'':'empty'}" >
$ {
    items .length ? `<div><span class="tx-day-dot ${dotClass}"></span></div> <div>$

{
    items .length
}

$ {
    t('giao dịch','tx')
}

</div >
<div class="tx-day-amount" > $ {
    amountLabel
}

$ {
    amountLabel ?' VND':''
}

</div > `
: t('Không có giao dịch','No transactions')
}
</div >
</button >
`;
}

qs('transactionMiniCalendarGrid').innerHTML = html;
}

function openDay(dateIso) {
    const items = baseFilteredTransactions().filter(x=>x.transactionDate===dateIso).sort((a,b)=>b.id.localeCompare(a.id));
    qs('transactionDayTitle').textContent = `$

{
    t('Giao dịch ngày','Transactions on')
}

$ {
    fmtDate(parseISO(dateIso))
}

`;
qs('transactionDaySubTitle').textContent = fmtLong(parseISO(dateIso));
qs('dayStatCount').textContent = items.length;

const income = items.filter(x=>x.transactionType==='income').reduce((s,x)=>s+Number(x.amountValue),0);
const expense = items.filter(x=>x.transactionType==='expense').reduce((s,x)=>s+Number(x.amountValue),0);

qs('dayStatIncome').textContent = fmtMoney(income);
qs('dayStatExpense').textContent = fmtMoney(expense);

qs('transactionDayList').innerHTML = items.map(tx => ` <div class="tx-day-item"> <div class="tx-main-icon" style="background:${colorAlpha(tx.categoryColor,.15)};color:${tx.categoryColor}"> ${iconMarkup(tx.categoryIcon, tx.categoryName)} </div> <div> <h6>${escapeHtml(tx.note)}</h6> <p>${escapeHtml(tx.categoryName)} · ${escapeHtml(tx.walletName)} · ${escapeHtml(tx.recurringBadgeText)}</p> </div> <div class="tx-amount ${tx.transactionType==='income'?'income':'expense'}">${escapeHtml(tx.amountText)}</div> </div> `).join('');

dayOffcanvas?.show();
}

function syncDayNavigator() {
    const card = qs('dayNavigatorCard');
    card .classList.toggle('d-none', state.period !== 'today');
    qs('currentDayPill').textContent = fmtLong(state.currentDay);
    const available = daySet(baseFilteredTransactions());
    const idx = available.indexOf(iso(state.currentDay));
    qs('dayPrevBtn').disabled = idx <= 0;
    qs('dayNextBtn').disabled = idx < 0 || idx >= available.length-1;
}

function syncPeriodUi() {
    const custom = state.period === 'custom';
    qs('customDateRangeWrap').classList.toggle('d-none', !custom);
}

function rerender() {
    applyFilters();
    ensureChart('income','incomeDonutChart','incomeDonutTotal','incomeLegend');
    ensureChart('expense','expenseDonutChart','expenseDonutTotal','expenseLegend');
    renderList();
    renderCalendar();
    syncDayNavigator();
    syncPeriodUi();
}

function fillCategoryGrid(gridId, currentId) {
    document .querySelectorAll(`#${gridId} .tx-category-chip`).forEach(btn => btn.classList.toggle('active', btn.dataset.id === currentId));
}

function setPreview(prefix, tx) {
    const target = qs(`${prefix}HeroIcon`);
    if(target) target.innerHTML = iconMarkup(tx.categoryIcon, tx.categoryName);
    if(qs(`${prefix}HeroIconWrap`)) qs(`${prefix}HeroIconWrap`).style.background = colorAlpha(tx.categoryColor,.15);
    if(qs(`${prefix}NoteText`)) qs(`${prefix}NoteText`).textContent = tx.note;
    if(qs(`${prefix}AmountText`)) qs(`${prefix}AmountText`).textContent = tx.amountText;
    if(qs(`${prefix}CategoryText`)) qs(`${prefix}CategoryText`).textContent = tx.categoryName;
    if(qs(`${prefix}WalletText`)) qs(`${prefix}WalletText`).textContent = tx.walletName;
    if(qs(`${prefix}DateText`)) qs(`${prefix}DateText`).textContent = tx.transactionDateText;
    if(qs(`${prefix}TypeText`)) qs(`${prefix}TypeText`).textContent = tx.transactionType === 'income' ? t('Thu nhập','Income') : t('Chi tiêu','Expense');
    if(qs(`${prefix}BadgeText`)) qs(`${prefix}BadgeText`).textContent = tx.recurringBadgeText;
}

function openDetail(id) {
    const tx = transactions.find(x=>x.id===id);
    if(!tx) return;
    state .detailId = id;
    setPreview('detail', tx);
    qs('detailEditWallet').value = tx.walletId;
    qs('detailEditAmount').value = tx.amountValue;
    detailDateFp ?.setDate(tx.transactionDate, true, 'Y-m-d');
    qs('detailEditRecurrence').value = badgeToInterval(tx.recurringBadgeText);
    qs('detailEditNote').value = tx.note === t('Không có ghi chú','No note') ? '' : tx.note;
    qs('detailEditType').value = tx.transactionType;
    document .querySelectorAll('#detailTypeSwitch button').forEach(b=>b.classList.toggle('active', b.dataset.value===tx.transactionType));
    qs('detailEditCategoryId').value = tx.categoryId;
    qs('detailEditCategoryIcon').value = tx.categoryIcon;
    qs('detailEditCategoryColor').value = tx.categoryColor;
    fillCategoryGrid('detailCategoryGrid', tx.categoryId);
    detailModal ?.show();
}

function badgeToInterval(badge) {
    const m =

{
    [t('Một lần','One-time')]:'', [t('Hàng ngày','Daily')]:'daily', [t('Hàng tuần','Weekly')]:'weekly', [t('Hàng tháng','Monthly')]:'monthly', [t('Hàng năm','Yearly')]:'yearly'
}

;
return m[badge] ?? '';
}

function intervalToBadge(v) {
    const m =

{
    '':t('Một lần','One-time'), daily:t('Hàng ngày','Daily'), weekly:t('Hàng tuần','Weekly'), monthly:t('Hàng tháng','Monthly'), yearly:t('Hàng năm','Yearly')
}

;
return m[v ?? ''] ?? t('Một lần','One-time');
}

function bindEvents() {
    document .querySelectorAll('#transactionTypeTabs button').forEach(btn => btn.addEventListener('click', ()=>{
        document.querySelectorAll('#transactionTypeTabs button').forEach(x=>x.classList.remove('active'));
        btn.classList.add('active');
        state.type = btn.dataset.type;
        rerender();
      }) );
    qs('transactionSearchInput').addEventListener('input', e => {
      state.keyword = e.target.value.trim().toLowerCase();
      rerender();
    });
    qs('walletFilter').addEventListener('change', e => {
      state.walletId = e.target.value;
      rerender();
    });
    qs('periodFilter').addEventListener('change', e => {
      state.period = e.target.value;
      rerender();
    });
    if(fromFp) qs('fromDateFilter').addEventListener('change', e=>{
      state.from = e.target.value || null;
      rerender();
    });
    if(toFp) qs('toDateFilter').addEventListener('change', e=>{
      state.to = e.target.value || null;
      rerender();
    });
    qs('dayPrevBtn').addEventListener('click', ()=> shiftDay(-1));
    qs('dayNextBtn').addEventListener('click', ()=> shiftDay(1));
    qs('transactionPagination').addEventListener('click', e=>{
      const btn = e.target.closest('[data-page]');
      if(!btn) return;
      state.currentPage = Number(btn.dataset.page);
      renderList();
    });
    qs('transactionListShell').addEventListener('click', e=>{
      const btn = e.target.closest('[data-action]');
      if(!btn) return;
      const id = btn.dataset.id;
      if(btn.dataset.action==='view') openDetail(id);
      else removeTx(id);
    });
    qs('transactionMiniCalendarGrid').addEventListener('click', e=>{
      const cell = e.target.closest('[data-date]');
      if(!cell) return;
      openDay(cell.dataset.date);
    });
    qs('calendarPrevBtn').addEventListener('click', ()=>{
      state.currentMonth = monthStart(new Date(state.currentMonth.getFullYear(), state.currentMonth.getMonth()-1, 1));
      renderCalendar();
    });
    qs('calendarNextBtn').addEventListener('click', ()=>{
      state.currentMonth = monthStart(new Date(state.currentMonth.getFullYear(), state.currentMonth.getMonth()+1, 1));
      renderCalendar();
    });
    document .querySelectorAll('#addTypeSwitch button').forEach(btn => btn.addEventListener('click', ()=>{
        document.querySelectorAll('#addTypeSwitch button').forEach(x=>x.classList.remove('active'));
        btn.classList.add('active');
        qs('addTransactionType').value = btn.dataset.value;
      }) );
    document .querySelectorAll('#detailTypeSwitch button').forEach(btn => btn.addEventListener('click', ()=>{
        document.querySelectorAll('#detailTypeSwitch button').forEach(x=>x.classList.remove('active'));
        btn.classList.add('active');
        qs('detailEditType').value = btn.dataset.value;
      }) );
    document .querySelectorAll('#addCategoryGrid .tx-category-chip').forEach(btn => btn.addEventListener('click', ()=>selectCategory('add', btn)) );
    document .querySelectorAll('#detailCategoryGrid .tx-category-chip').forEach(btn => btn.addEventListener('click', ()=>selectCategory('detail', btn)) );
    qs('btnSaveTransactionStatic').addEventListener('click', createTx);
    qs('btnUpdateTransactionStatic').addEventListener('click', updateTx);
    qs('btnDeleteTransactionStatic').addEventListener('click', ()=>{
      if(state.detailId) removeTx(state.detailId, true);
    });
    ['addTransactionAmount','addTransactionWallet','addTransactionRecurrence','addTransactionNote'].forEach(id => qs(id)?.addEventListener('input', updateAddPreview) );
    qs('addTransactionWallet')?.addEventListener('change', updateAddPreview);
    qs('addTransactionRecurrence')?.addEventListener('change', updateAddPreview);
}

function shiftDay(delta) {
    const available = daySet(baseFilteredTransactions());
    const idx = available.indexOf(iso(state.currentDay));
    if(idx < 0) return;
    const next = available[idx + delta];
    if(!next) return;
    state .currentDay = parseISO(next);
    rerender();
}

function selectCategory(prefix, btn) {
    fillCategoryGrid(prefix+'CategoryGrid', btn.dataset.id);
    if(qs(`${prefix}TransactionCategoryId`)) qs(`${prefix}TransactionCategoryId`).value = btn.dataset.id;
    if(qs(`${prefix}EditCategoryId`)) qs(`${prefix}EditCategoryId`).value = btn.dataset.id;
    if(qs(`${prefix}TransactionCategoryIcon`)) qs(`${prefix}TransactionCategoryIcon`).value = btn.dataset.icon;
    if(qs(`${prefix}EditCategoryIcon`)) qs(`${prefix}EditCategoryIcon`).value = btn.dataset.icon;
    if(qs(`${prefix}TransactionCategoryColor`)) qs(`${prefix}TransactionCategoryColor`).value = btn.dataset.color;
    if(qs(`${prefix}EditCategoryColor`)) qs(`${prefix}EditCategoryColor`).value = btn.dataset.color;
    if(prefix==='add') updateAddPreview();
}

function updateAddPreview() {
    const wallet = walletInfo(qs('addTransactionWallet').value);
    const catId = qs('addTransactionCategoryId').value || categories[0]?.category_id;
    const cat = categoryInfo(catId) || categories[0];
    const tx =

{
    note: qs('addTransactionNote').value.trim() || t('Chưa có ghi chú cho giao dịch này.','No note yet.'), amountText: fmtMoney(qs('addTransactionAmount').value || 0), categoryName: cat?.category_name || '---', categoryIcon: cat?.icon || 'bx bx-category', categoryColor: cat?.color || '#8592A3', walletName: wallet?.wallet_name || '---', transactionDateText: addDateFp?.input?.value ? fmtDate(parseISO(addDateFp.input.value)) : fmtDate(state.currentDay), recurringBadgeText: intervalToBadge(qs('addTransactionRecurrence').value), transactionType: qs('addTransactionType').value || 'expense'
}

;

qs('addPreviewIcon').innerHTML = iconMarkup(tx.categoryIcon, tx.categoryName);
qs('addPreviewIconWrap').style.background = colorAlpha(tx.categoryColor,.15);
qs('addPreviewNote').textContent = tx.note;
qs('addPreviewAmount').textContent = tx.amountText;
qs('addPreviewCategory').textContent = tx.categoryName;
qs('addPreviewWallet').textContent = tx.walletName;
qs('addPreviewDate').textContent = tx.transactionDateText;
qs('addPreviewRepeat').textContent = tx.recurringBadgeText;
}

async function createTx() {
    const categoryId = qs('addTransactionCategoryId').value || categories[0]?.category_id;
    const payload =

{
    wallet_id: qs('addTransactionWallet').value, category_id: categoryId, transaction_type: qs('addTransactionType').value, amount: Number(qs('addTransactionAmount').value || 0), transaction_date: qs('addTransactionDate').value || iso(state.currentDay), note: qs('addTransactionNote').value.trim() || null, is_recurring: !!qs('addTransactionRecurrence').value, recur_interval: qs('addTransactionRecurrence').value || null
}

;

if(!payload.wallet_id || !payload.category_id || !payload.amount || payload.amount <= 0) {
    return alert(t('Vui lòng nhập đủ ví, danh mục và số tiền hợp lệ.','Please fill wallet, category and a valid amount.'));
}

const res = await fetch('/Transaction/CreateAjax',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify(payload)
    });

const json = await res.json();
if(!res.ok || !json.success) return alert(json.message || 'Error');
location.reload();
}

async function updateTx() {
    if(!state.detailId) return;
    const payload =

{
    wallet_id: qs('detailEditWallet').value, category_id: qs('detailEditCategoryId').value, transaction_type: qs('detailEditType').value, amount: Number(qs('detailEditAmount').value || 0), transaction_date: qs('detailEditDate').value || null, note: qs('detailEditNote').value.trim() || null, is_recurring: !!qs('detailEditRecurrence').value, recur_interval: qs('detailEditRecurrence').value || null
}

;

const res = await fetch(`/Transaction/UpdateAjax?id=${encodeURIComponent(state.detailId)}`,{
      method:'PUT',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify(payload)
    });

const json = await res.json();
if(!res.ok || !json.success) return alert(json.message || 'Error');
location.reload();
}

async function removeTx(id, closeDetail) {
    if(!confirm(t('Bạn có chắc muốn xóa giao dịch này?','Delete this transaction?'))) return;
    const res = await fetch(`/Transaction/DeleteAjax?id=${encodeURIComponent(id)}`,{method:'DELETE'});
    const json = await res.json().catch(()=>({success:res.ok}));
    if(!res.ok || !json.success) return alert(json.message || 'Error');
    if(closeDetail) detailModal?.hide();
    location .reload();
}

function seedAddDefaults() {
    if(wallets[0]) qs('addTransactionWallet').value = wallets[0].wallet_id;
    if(categories[0])

{
    qs('addTransactionCategoryId').value = categories[0].category_id;
    qs('addTransactionCategoryIcon').value = categories[0].icon || 'bx bx-category';
    qs('addTransactionCategoryColor').value = categories[0].color || '#8592A3';
    fillCategoryGrid('addCategoryGrid', categories[0].category_id);
}

addDateFp?.setDate(state.currentDay, true, 'Y-m-d');
updateAddPreview();
}

bindEvents();
seedAddDefaults();
rerender();
}
);
