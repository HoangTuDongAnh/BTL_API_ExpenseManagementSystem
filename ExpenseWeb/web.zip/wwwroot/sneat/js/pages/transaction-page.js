﻿document.addEventListener("DOMContentLoaded", function () {
    const addModalEl = document.getElementById("addTransactionModal");
    const detailModalEl = document.getElementById("transactionDetailModal");
    const dayOffcanvasEl = document.getElementById("transactionDayOffcanvas");

    const addModal = addModalEl ? new bootstrap.Modal(addModalEl) : null;
    const detailModal = detailModalEl ? new bootstrap.Modal(detailModalEl) : null;
    const dayOffcanvas = dayOffcanvasEl ? new bootstrap.Offcanvas(dayOffcanvasEl) : null;

    const toastSaved = document.getElementById("transactionSavedToast") ? new bootstrap.Toast(document.getElementById("transactionSavedToast")) : null;
    const toastUpdated = document.getElementById("transactionUpdatedToast") ? new bootstrap.Toast(document.getElementById("transactionUpdatedToast")) : null;
    const toastDeleted = document.getElementById("transactionDeletedToast") ? new bootstrap.Toast(document.getElementById("transactionDeletedToast")) : null;
    const toastDuplicated = document.getElementById("transactionDuplicatedToast") ? new bootstrap.Toast(document.getElementById("transactionDuplicatedToast")) : null;

    function formatNumber(value) {
        const number = Number(value || 0);
        return number.toLocaleString("vi-VN");
    }

    function hexToRgba(hex, alpha) {
        if (!hex || !hex.startsWith("#") || hex.length !== 7) {
            return `rgba(105,108,255,${alpha})`;
        }
        const r = parseInt(hex.slice(1, 3), 16);
        const g = parseInt(hex.slice(3, 5), 16);
        const b = parseInt(hex.slice(5, 7), 16);
        return `rgba(${r}, ${g}, ${b}, ${alpha})`;
    }

    function currentTypeLabel(type) {
        return type === "income" ? "Thu nhập" : "Chi tiêu";
    }

    function currentTypeAmount(amount, type) {
        const prefix = type === "income" ? "+" : "-";
        return `${prefix}${formatNumber(amount)} VND`;
    }

    function setSwitchState(rootId, type) {
        const root = document.getElementById(rootId);
        if (!root) return;

        root.querySelectorAll("button").forEach(function (btn) {
            btn.classList.toggle("active", btn.dataset.type === type);
        });
    }

    function bindTypeSwitch(rootId, selectId, onChange) {
        const root = document.getElementById(rootId);
        const select = document.getElementById(selectId);
        if (!root || !select) return;

        root.querySelectorAll("button").forEach(function (btn) {
            btn.addEventListener("click", function () {
                const type = btn.dataset.type || "expense";
                select.value = type;
                setSwitchState(rootId, type);
                if (typeof onChange === "function") onChange(type);
            });
        });

        select.addEventListener("change", function () {
            setSwitchState(rootId, select.value);
            if (typeof onChange === "function") onChange(select.value);
        });

        setSwitchState(rootId, select.value);
    }

    function updateAddPreview() {
        const title = document.getElementById("addTransactionTitle")?.value || "Giao dịch mới";
        const wallet = document.getElementById("addTransactionWallet")?.value || "Ví tiền mặt";
        const type = document.getElementById("addTransactionType")?.value || "expense";
        const date = document.getElementById("addTransactionDate")?.value || "2026-04-04";
        const amount = document.getElementById("addTransactionAmount")?.value || 0;
        const recurrence = document.getElementById("addTransactionRecurrence")?.value || "Không";
        const note = document.getElementById("addTransactionNote")?.value || "Không có ghi chú";
        const category = document.getElementById("addTransactionCategory")?.value || "Ăn uống";

        const previewTitle = document.getElementById("addPreviewTitle");
        const previewWallet = document.getElementById("addPreviewWallet");
        const previewDate = document.getElementById("addPreviewDate");
        const previewAmount = document.getElementById("addPreviewAmount");
        const previewRecurrence = document.getElementById("addPreviewRecurrence");
        const previewNote = document.getElementById("addPreviewNote");
        const previewCategoryText = document.getElementById("addPreviewCategoryText");
        const previewTypeBadge = document.getElementById("addPreviewTypeBadge");

        if (previewTitle) previewTitle.textContent = title;
        if (previewWallet) previewWallet.textContent = wallet;
        if (previewDate) previewDate.textContent = date;
        if (previewAmount) {
            previewAmount.textContent = currentTypeAmount(amount, type);
            previewAmount.classList.toggle("text-success", type === "income");
            previewAmount.classList.toggle("text-danger", type === "expense");
        }
        if (previewRecurrence) previewRecurrence.textContent = recurrence;
        if (previewNote) previewNote.textContent = note;
        if (previewCategoryText) previewCategoryText.textContent = category;
        if (previewTypeBadge) {
            previewTypeBadge.textContent = currentTypeLabel(type);
            previewTypeBadge.className = "badge " + (type === "income" ? "bg-label-success" : "bg-label-danger");
        }
    }

    function setupCategorySelect(config) {
        const root = document.getElementById(config.rootId);
        if (!root) return;

        const toggle = root.querySelector(".transaction-category-select-toggle");
        const hiddenInput = document.getElementById(config.hiddenInputId);
        const previewText = document.getElementById(config.previewTextId);
        const previewIconWrap = document.getElementById(config.previewIconWrapId);
        const extraIcon = config.extraIconId ? document.getElementById(config.extraIconId) : null;
        const extraWrap = config.extraWrapId ? document.getElementById(config.extraWrapId) : null;
        const options = root.querySelectorAll(".transaction-category-option");

        if (toggle) {
            toggle.addEventListener("click", function (e) {
                e.stopPropagation();
                document.querySelectorAll(".transaction-category-select.open").forEach(function (item) {
                    if (item !== root) item.classList.remove("open");
                });
                root.classList.toggle("open");
            });
        }

        options.forEach(function (option) {
            option.addEventListener("click", function () {
                const name = option.dataset.name || "Ăn uống";
                const icon = option.dataset.icon || "bx bx-restaurant";
                const color = option.dataset.color || "#696cff";

                if (hiddenInput) hiddenInput.value = name;
                if (previewText) previewText.textContent = name;
                if (previewIconWrap) previewIconWrap.innerHTML = `<i class="${icon}"></i>`;

                if (extraIcon) extraIcon.className = icon;
                if (extraWrap) {
                    extraWrap.style.color = color;
                    extraWrap.style.background = hexToRgba(color, 0.14);
                }

                root.classList.remove("open");

                if (typeof config.onSelect === "function") {
                    config.onSelect({ name, icon, color });
                }
            });
        });
    }

    document.addEventListener("click", function (e) {
        document.querySelectorAll(".transaction-category-select.open").forEach(function (selectEl) {
            if (!selectEl.contains(e.target)) {
                selectEl.classList.remove("open");
            }
        });
    });

    bindTypeSwitch("addTransactionTypeSwitch", "addTransactionType", updateAddPreview);
    bindTypeSwitch("detailTransactionTypeSwitch", "detailEditType");

    ["addTransactionTitle", "addTransactionAmount", "addTransactionDate", "addTransactionNote"].forEach(function (id) {
        const el = document.getElementById(id);
        if (el) el.addEventListener("input", updateAddPreview);
    });

    ["addTransactionWallet", "addTransactionType", "addTransactionRecurrence"].forEach(function (id) {
        const el = document.getElementById(id);
        if (el) el.addEventListener("change", updateAddPreview);
    });

    setupCategorySelect({
        rootId: "addCategorySelect",
        hiddenInputId: "addTransactionCategory",
        previewTextId: "addCategoryPreviewText",
        previewIconWrapId: "addCategoryPreviewIcon",
        extraIconId: "addPreviewCategoryIcon",
        extraWrapId: "addPreviewCategoryIconWrap",
        onSelect: updateAddPreview
    });

    setupCategorySelect({
        rootId: "detailCategorySelect",
        hiddenInputId: "detailEditCategory",
        previewTextId: "detailCategoryPreviewText",
        previewIconWrapId: "detailCategoryPreviewIcon",
        extraIconId: "detailCategoryIcon",
        extraWrapId: "detailCategoryIconWrap",
        onSelect: function (category) {
            const title = document.getElementById("detailCategoryTitle");
            if (title) title.textContent = category.name;
        }
    });

    const detailFieldsMap = {
        id: document.getElementById("detailId"),
        badge: document.getElementById("detailBadge"),
        categoryTitle: document.getElementById("detailCategoryTitle"),
        wallet: document.getElementById("detailWallet"),
        amount: document.getElementById("detailAmount"),
        dateTime: document.getElementById("detailDateTime"),
        currency: document.getElementById("detailCurrency"),
        editTitle: document.getElementById("detailEditTitle"),
        editWallet: document.getElementById("detailEditWallet"),
        editType: document.getElementById("detailEditType"),
        editCategory: document.getElementById("detailEditCategory"),
        editDate: document.getElementById("detailEditDate"),
        editTime: document.getElementById("detailEditTime"),
        editNote: document.getElementById("detailEditNote"),
        iconWrap: document.getElementById("detailCategoryIconWrap"),
        icon: document.getElementById("detailCategoryIcon"),
        categoryPreviewText: document.getElementById("detailCategoryPreviewText"),
        categoryPreviewIcon: document.getElementById("detailCategoryPreviewIcon")
    };

    if (detailModalEl) {
        detailModalEl.addEventListener("show.bs.modal", function (event) {
            const trigger = event.relatedTarget;
            if (!trigger) return;

            const data = trigger.dataset;
            const type = data.type || "expense";
            const color = data.categoryColor || "#696cff";
            const icon = data.categoryIcon || "bx bx-receipt";

            if (detailFieldsMap.id) detailFieldsMap.id.textContent = data.id || "TXN0000000000";
            if (detailFieldsMap.badge) {
                detailFieldsMap.badge.textContent = data.badge || "Một lần";
                detailFieldsMap.badge.className = "badge " + (type === "income" ? "bg-label-success" : "bg-label-danger");
            }
            if (detailFieldsMap.categoryTitle) detailFieldsMap.categoryTitle.textContent = data.category || "Danh mục";
            if (detailFieldsMap.wallet) detailFieldsMap.wallet.textContent = data.wallet || "Ví";
            if (detailFieldsMap.amount) {
                detailFieldsMap.amount.textContent = `${data.amount || "0"} ${data.currency || "VND"}`;
                detailFieldsMap.amount.classList.toggle("text-success", type === "income");
                detailFieldsMap.amount.classList.toggle("text-danger", type === "expense");
            }
            if (detailFieldsMap.dateTime) detailFieldsMap.dateTime.textContent = `${data.date || ""} • ${data.time || ""}`;
            if (detailFieldsMap.currency) detailFieldsMap.currency.textContent = data.currency || "VND";
            if (detailFieldsMap.editTitle) detailFieldsMap.editTitle.value = data.title || "";
            if (detailFieldsMap.editWallet) detailFieldsMap.editWallet.value = data.wallet || "Ví tiền mặt";
            if (detailFieldsMap.editType) detailFieldsMap.editType.value = type;
            if (detailFieldsMap.editCategory) detailFieldsMap.editCategory.value = data.category || "";
            if (detailFieldsMap.editDate) detailFieldsMap.editDate.value = data.date || "";
            if (detailFieldsMap.editTime) detailFieldsMap.editTime.value = data.time || "";
            if (detailFieldsMap.editNote) detailFieldsMap.editNote.value = data.note || "";
            if (detailFieldsMap.icon) detailFieldsMap.icon.className = icon;
            if (detailFieldsMap.iconWrap) {
                detailFieldsMap.iconWrap.style.color = color;
                detailFieldsMap.iconWrap.style.background = hexToRgba(color, 0.14);
            }
            if (detailFieldsMap.categoryPreviewText) detailFieldsMap.categoryPreviewText.textContent = data.category || "Danh mục";
            if (detailFieldsMap.categoryPreviewIcon) detailFieldsMap.categoryPreviewIcon.innerHTML = `<i class="${icon}"></i>`;

            setSwitchState("detailTransactionTypeSwitch", type);
        });
    }

    function applyTableFilter() {
        const keyword = (document.getElementById("transactionSearchInput")?.value || "").trim().toLowerCase();
        const wallet = document.getElementById("walletFilter")?.value || "all";
        const activeTypeBtn = document.querySelector("#transactionTypeTabs button.active");
        const activeType = activeTypeBtn ? activeTypeBtn.dataset.type || "all" : "all";

        let visibleCount = 0;

        document.querySelectorAll(".transaction-row").forEach(function (row) {
            const rowType = row.dataset.type || "expense";
            const rowWallet = row.dataset.wallet || "";
            const rowSearch = row.dataset.search || "";

            const matchKeyword = !keyword || rowSearch.includes(keyword);
            const matchWallet = wallet === "all" || rowWallet === wallet;
            const matchType = activeType === "all" || rowType === activeType;
            const show = matchKeyword && matchWallet && matchType;

            row.style.display = show ? "" : "none";
            if (show) visibleCount += 1;
        });

        const summary = document.getElementById("transactionTableSummary");
        if (summary) {
            summary.textContent = `Hiển thị ${visibleCount} giao dịch tĩnh`;
        }

        const tableWrapper = document.getElementById("transactionTableWrapper");
        const emptyState = document.getElementById("transactionEmptyState");

        if (tableWrapper && emptyState) {
            if (visibleCount === 0) {
                tableWrapper.style.display = "none";
                emptyState.classList.add("show");
            } else {
                tableWrapper.style.display = "";
                emptyState.classList.remove("show");
            }
        }
    }

    document.querySelectorAll("#transactionTypeTabs button").forEach(function (btn) {
        btn.addEventListener("click", function () {
            document.querySelectorAll("#transactionTypeTabs button").forEach(function (item) {
                item.classList.remove("active");
            });
            btn.classList.add("active");
            applyTableFilter();
        });
    });

    ["transactionSearchInput", "walletFilter"].forEach(function (id) {
        const el = document.getElementById(id);
        if (el) el.addEventListener(id === "transactionSearchInput" ? "input" : "change", applyTableFilter);
    });

    const periodFilter = document.getElementById("periodFilter");
    const fromDateWrap = document.getElementById("fromDateWrap");
    const toDateWrap = document.getElementById("toDateWrap");

    if (periodFilter) {
        periodFilter.addEventListener("change", function () {
            const isCustom = periodFilter.value === "custom";
            if (fromDateWrap) fromDateWrap.classList.toggle("d-none", !isCustom);
            if (toDateWrap) toDateWrap.classList.toggle("d-none", !isCustom);
        });
    }

    document.querySelectorAll(".transaction-delete-trigger").forEach(function (btn) {
        btn.addEventListener("click", function () {
            if (toastDeleted) toastDeleted.show();
        });
    });

    document.querySelectorAll(".transaction-duplicate-trigger").forEach(function (btn) {
        btn.addEventListener("click", function () {
            if (toastDuplicated) toastDuplicated.show();
        });
    });

    const btnSave = document.getElementById("btnSaveTransactionStatic");
    if (btnSave) {
        btnSave.addEventListener("click", function () {
            if (addModal) addModal.hide();
            if (toastSaved) toastSaved.show();
        });
    }

    const btnUpdate = document.getElementById("btnUpdateTransactionStatic");
    if (btnUpdate) {
        btnUpdate.addEventListener("click", function () {
            if (toastUpdated) toastUpdated.show();
        });
    }

    const btnDelete = document.getElementById("btnDeleteTransactionStatic");
    if (btnDelete) {
        btnDelete.addEventListener("click", function () {
            if (detailModal) detailModal.hide();
            if (toastDeleted) toastDeleted.show();
        });
    }

    function parseVNDateToISO(dateStr) {
        if (!dateStr) return null;
        const parts = dateStr.split("/");
        if (parts.length !== 3) return null;
        const dd = parts[0].padStart(2, "0");
        const mm = parts[1].padStart(2, "0");
        const yyyy = parts[2];
        return `${yyyy}-${mm}-${dd}`;
    }

    function formatSelectedDateLabel(dateObj) {
        return dateObj.toLocaleDateString("vi-VN", {
            weekday: "long",
            day: "2-digit",
            month: "2-digit",
            year: "numeric"
        });
    }

    function getCategoryIcon(categoryName) {
        const map = {
            "Ăn uống": "bx bx-restaurant",
            "Di chuyển": "bx bx-car",
            "Mua sắm": "bx bx-shopping-bag",
            "Hóa đơn": "bx bx-receipt",
            "Giải trí": "bx bx-movie-play",
            "Sức khỏe": "bx bx-plus-medical",
            "Lương": "bx bx-wallet",
            "Thưởng": "bx bx-gift"
        };
        return map[categoryName] || "bx bx-category";
    }

    const selectedDateCount = document.getElementById("selectedDateCount");
    const selectedDateIncome = document.getElementById("selectedDateIncome");
    const selectedDateExpense = document.getElementById("selectedDateExpense");
    const transactionDayList = document.getElementById("transactionDayList");
    const transactionCalendarEl = document.getElementById("transactionCalendar");
    const dayOffcanvasTitle = document.getElementById("transactionDayOffcanvasLabel");
    const dayOffcanvasSubLabel = document.getElementById("transactionDayOffcanvasSubLabel");

    const dailyIncomeRing = document.getElementById("dailyIncomeRing");
    const dailyExpenseRing = document.getElementById("dailyExpenseRing");
    const dailyIncomeTotal = document.getElementById("dailyIncomeTotal");
    const dailyExpenseTotal = document.getElementById("dailyExpenseTotal");
    const dailyIncomeLegend = document.getElementById("dailyIncomeLegend");
    const dailyExpenseLegend = document.getElementById("dailyExpenseLegend");
    const dailyIncomeDateLabel = document.getElementById("dailyIncomeDateLabel");
    const dailyExpenseDateLabel = document.getElementById("dailyExpenseDateLabel");

    const transactionRows = Array.from(document.querySelectorAll(".transaction-row"));

    const calendarTransactions = transactionRows.map(function (row) {
        return {
            id: row.dataset.id || "",
            title: row.dataset.title || "Giao dịch",
            category: row.dataset.category || "Khác",
            categoryIcon: row.dataset.categoryIcon || getCategoryIcon(row.dataset.category || ""),
            categoryColor: row.dataset.categoryColor || "#696cff",
            wallet: row.dataset.wallet || "Ví",
            date: row.dataset.date || "",
            time: row.dataset.time || "",
            amount: row.dataset.amount || "0",
            currency: row.dataset.currency || "VND",
            note: row.dataset.note || "",
            badge: row.dataset.badge || "Một lần",
            type: row.dataset.type || "expense",
            isoDate: parseVNDateToISO(row.dataset.date || "")
        };
    }).filter(function (item) {
        return !!item.isoDate;
    });

    const transactionsByDate = {};
    calendarTransactions.forEach(function (item) {
        if (!transactionsByDate[item.isoDate]) {
            transactionsByDate[item.isoDate] = [];
        }
        transactionsByDate[item.isoDate].push(item);
    });

    function openDetailFromTransaction(item) {
        if (!detailModalEl || !item) return;

        const fakeTrigger = document.createElement("button");
        fakeTrigger.dataset.id = item.id;
        fakeTrigger.dataset.title = item.title;
        fakeTrigger.dataset.category = item.category;
        fakeTrigger.dataset.categoryIcon = item.categoryIcon;
        fakeTrigger.dataset.categoryColor = item.categoryColor;
        fakeTrigger.dataset.wallet = item.wallet;
        fakeTrigger.dataset.type = item.type;
        fakeTrigger.dataset.amount = item.amount;
        fakeTrigger.dataset.date = item.date;
        fakeTrigger.dataset.time = item.time;
        fakeTrigger.dataset.note = item.note;
        fakeTrigger.dataset.badge = item.badge;
        fakeTrigger.dataset.currency = item.currency;

        const modalEvent = new CustomEvent("show.bs.modal", { bubbles: true });
        Object.defineProperty(modalEvent, "relatedTarget", { value: fakeTrigger });

        detailModalEl.dispatchEvent(modalEvent);
        if (detailModal) detailModal.show();
    }

    function buildRingSegments(items) {
        if (!items.length) return "conic-gradient(#e9ecef 0 100%)";

        const total = items.reduce(function (sum, item) {
            return sum + (Number(String(item.amount).replace(/[^\d.-]/g, "")) || 0);
        }, 0);

        if (total <= 0) return "conic-gradient(#e9ecef 0 100%)";

        let current = 0;
        const parts = items.map(function (item) {
            const value = Number(String(item.amount).replace(/[^\d.-]/g, "")) || 0;
            const percent = (value / total) * 100;
            const start = current;
            const end = current + percent;
            current = end;
            return `${item.categoryColor} ${start}% ${end}%`;
        });

        return `conic-gradient(${parts.join(", ")})`;
    }

    function renderRingLegend(container, items) {
        if (!container) return;

        if (!items.length) {
            container.innerHTML = `<div class="transaction-ring-empty-text">Chưa có dữ liệu.</div>`;
            return;
        }

        const total = items.reduce(function (sum, item) {
            return sum + (Number(String(item.amount).replace(/[^\d.-]/g, "")) || 0);
        }, 0);

        container.innerHTML = items.map(function (item) {
            const value = Number(String(item.amount).replace(/[^\d.-]/g, "")) || 0;
            const percent = total > 0 ? Math.round((value / total) * 100) : 0;
            return `
                <div class="transaction-ring-legend-item">
                    <div class="transaction-ring-legend-left">
                        <span class="transaction-ring-dot" style="background:${item.categoryColor}"></span>
                        <span>${item.category}</span>
                    </div>
                    <strong>${percent}%</strong>
                </div>
            `;
        }).join("");
    }

    function renderDailySummaryCards(dateStr) {
        const dateObj = new Date(dateStr + "T00:00:00");
        const items = (transactionsByDate[dateStr] || []).slice();

        const incomeItems = items.filter(function (x) { return x.type === "income"; });
        const expenseItems = items.filter(function (x) { return x.type === "expense"; });

        const incomeTotal = incomeItems.reduce(function (sum, item) {
            return sum + (Number(String(item.amount).replace(/[^\d.-]/g, "")) || 0);
        }, 0);

        const expenseTotal = expenseItems.reduce(function (sum, item) {
            return sum + (Number(String(item.amount).replace(/[^\d.-]/g, "")) || 0);
        }, 0);

        if (dailyIncomeTotal) dailyIncomeTotal.textContent = `${incomeTotal.toLocaleString("vi-VN")} VND`;
        if (dailyExpenseTotal) dailyExpenseTotal.textContent = `${expenseTotal.toLocaleString("vi-VN")} VND`;

        const label = formatSelectedDateLabel(dateObj);
        if (dailyIncomeDateLabel) dailyIncomeDateLabel.textContent = label;
        if (dailyExpenseDateLabel) dailyExpenseDateLabel.textContent = label;

        if (dailyIncomeRing) dailyIncomeRing.style.background = buildRingSegments(incomeItems);
        if (dailyExpenseRing) dailyExpenseRing.style.background = buildRingSegments(expenseItems);

        renderRingLegend(dailyIncomeLegend, incomeItems);
        renderRingLegend(dailyExpenseLegend, expenseItems);
    }

    function renderTransactionDayList(dateStr) {
        if (!transactionDayList) return;

        const dateObj = new Date(dateStr + "T00:00:00");
        const transactionsOfDay = (transactionsByDate[dateStr] || []).slice().sort(function (a, b) {
            return (a.time || "").localeCompare(b.time || "");
        });

        if (dayOffcanvasTitle) dayOffcanvasTitle.textContent = "Giao dịch trong ngày";
        if (dayOffcanvasSubLabel) dayOffcanvasSubLabel.textContent = formatSelectedDateLabel(dateObj);

        let incomeTotal = 0;
        let expenseTotal = 0;

        transactionsOfDay.forEach(function (item) {
            const numeric = Number(String(item.amount).replace(/[^\d.-]/g, "")) || 0;
            if (item.type === "income") incomeTotal += numeric;
            else expenseTotal += numeric;
        });

        if (selectedDateCount) selectedDateCount.textContent = transactionsOfDay.length;
        if (selectedDateIncome) selectedDateIncome.textContent = `${incomeTotal.toLocaleString("vi-VN")} VND`;
        if (selectedDateExpense) selectedDateExpense.textContent = `${expenseTotal.toLocaleString("vi-VN")} VND`;

        if (!transactionsOfDay.length) {
            transactionDayList.innerHTML = `
                <div class="transaction-day-empty">
                    <div class="transaction-day-empty-icon">
                        <i class="bx bx-calendar-event"></i>
                    </div>
                    <h6 class="mb-1">Chưa có giao dịch</h6>
                    <p class="text-body-secondary mb-0">
                        Không có giao dịch nào trong ngày đang chọn.
                    </p>
                </div>
            `;
            return;
        }

        transactionDayList.innerHTML = transactionsOfDay.map(function (item, index) {
            const amountClass = item.type === "income" ? "income" : "expense";
            return `
                <div class="transaction-day-item" data-day-index="${index}">
                    <div class="transaction-day-item-left">
                        <span class="transaction-day-icon">
                            <i class="${item.categoryIcon}"></i>
                        </span>
                        <div class="transaction-day-meta">
                            <div class="transaction-day-title">${item.title}</div>
                            <div class="transaction-day-sub">${item.category} • ${item.wallet}</div>
                            <div class="transaction-day-note">${item.note || "Không có ghi chú"}</div>
                        </div>
                    </div>
                    <div class="transaction-day-item-right">
                        <div class="transaction-day-amount ${amountClass}">
                            ${item.amount} ${item.currency}
                        </div>
                        <div class="transaction-day-time">${item.time || "--:--"}</div>
                    </div>
                </div>
            `;
        }).join("");

        transactionDayList.querySelectorAll(".transaction-day-item").forEach(function (el) {
            el.addEventListener("click", function () {
                const index = Number(el.dataset.dayIndex || 0);
                const item = transactionsOfDay[index];
                openDetailFromTransaction(item);
            });
        });
    }

    function buildCalendarEvents() {
        return Object.keys(transactionsByDate).map(function (dateKey) {
            const list = transactionsByDate[dateKey];
            const incomeCount = list.filter(function (x) { return x.type === "income"; }).length;
            const expenseCount = list.filter(function (x) { return x.type === "expense"; }).length;
            const totalCount = list.length;

            return {
                start: dateKey,
                allDay: true,
                display: "block",
                extendedProps: {
                    incomeCount,
                    expenseCount,
                    totalCount
                }
            };
        });
    }

    let transactionCalendar = null;

    function showDayOffcanvas(dateStr) {
        renderTransactionDayList(dateStr);
        renderDailySummaryCards(dateStr);
        if (dayOffcanvas) dayOffcanvas.show();
    }

    function syncCalendarWithPeriodFilter() {
        if (!transactionCalendar) return;

        const value = periodFilter ? periodFilter.value : "month";
        const today = new Date();
        const todayIso = today.toISOString().split("T")[0];

        if (value === "today") {
            transactionCalendar.gotoDate(todayIso);
            markSelectedDay(todayIso);
            showDayOffcanvas(todayIso);
            return;
        }

        if (value === "week") {
            transactionCalendar.gotoDate(todayIso);
            markSelectedDay(todayIso);
            showDayOffcanvas(todayIso);
            return;
        }

        if (value === "month") {
            transactionCalendar.gotoDate(todayIso);
            markSelectedDay(todayIso);
            renderDailySummaryCards(todayIso);
            return;
        }

        if (value === "custom") {
            const fromValue = document.getElementById("fromDateFilter")?.value;
            if (fromValue) {
                transactionCalendar.gotoDate(fromValue);
                markSelectedDay(fromValue);
                showDayOffcanvas(fromValue);
            }
        }
    }

    function markSelectedDay(dateStr) {
        if (!transactionCalendarEl) return;
        transactionCalendarEl.querySelectorAll(".fc-daygrid-day").forEach(function (el) {
            el.classList.remove("fc-transaction-selected");
        });

        transactionCalendarEl.querySelectorAll(".fc-daygrid-day").forEach(function (el) {
            const cellDate = el.getAttribute("data-date");
            if (cellDate === dateStr) {
                el.classList.add("fc-transaction-selected");
            }
        });
    }

    if (transactionCalendarEl && typeof FullCalendar !== "undefined") {
        const today = new Date();
        const todayIso = today.toISOString().split("T")[0];

        transactionCalendar = new FullCalendar.Calendar(transactionCalendarEl, {
            initialView: "dayGridMonth",
            locale: "vi",
            height: "auto",
            firstDay: 1,
            headerToolbar: {
                left: "prev,next today",
                center: "title",
                right: ""
            },
            buttonText: {
                today: "Hôm nay"
            },
            events: buildCalendarEvents(),
            eventContent: function (arg) {
                const incomeCount = arg.event.extendedProps.incomeCount || 0;
                const expenseCount = arg.event.extendedProps.expenseCount || 0;
                const totalCount = arg.event.extendedProps.totalCount || 0;

                const wrapper = document.createElement("div");
                wrapper.className = "fc-transaction-badges";

                const totalBadge = document.createElement("span");
                totalBadge.className = "fc-transaction-badge total";
                totalBadge.innerHTML = `<span class="fc-transaction-badge-dot"></span>${totalCount}`;
                wrapper.appendChild(totalBadge);

                if (incomeCount > 0) {
                    const incomeBadge = document.createElement("span");
                    incomeBadge.className = "fc-transaction-badge income";
                    incomeBadge.innerHTML = `<span class="fc-transaction-badge-dot"></span>${incomeCount}`;
                    wrapper.appendChild(incomeBadge);
                }

                if (expenseCount > 0) {
                    const expenseBadge = document.createElement("span");
                    expenseBadge.className = "fc-transaction-badge expense";
                    expenseBadge.innerHTML = `<span class="fc-transaction-badge-dot"></span>${expenseCount}`;
                    wrapper.appendChild(expenseBadge);
                }

                return { domNodes: [wrapper] };
            },
            dateClick: function (info) {
                markSelectedDay(info.dateStr);
                showDayOffcanvas(info.dateStr);
            },
            datesSet: function () {
                setTimeout(function () {
                    markSelectedDay(todayIso);
                }, 0);
            }
        });

        transactionCalendar.render();
        markSelectedDay(todayIso);
        renderDailySummaryCards(todayIso);
    }

    if (periodFilter) {
        periodFilter.addEventListener("change", syncCalendarWithPeriodFilter);
    }

    ["fromDateFilter", "toDateFilter"].forEach(function (id) {
        const el = document.getElementById(id);
        if (el) {
            el.addEventListener("change", function () {
                if (periodFilter && periodFilter.value === "custom") {
                    syncCalendarWithPeriodFilter();
                }
            });
        }
    });

    updateAddPreview();
    applyTableFilter();
});