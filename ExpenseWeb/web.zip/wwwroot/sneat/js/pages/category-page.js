document.addEventListener("DOMContentLoaded", function () {
    const addModalEl = document.getElementById("addCategoryModal");
    const detailModalEl = document.getElementById("categoryDetailModal");
    const addModal = addModalEl ? new bootstrap.Modal(addModalEl) : null;
    const detailModal = detailModalEl ? new bootstrap.Modal(detailModalEl) : null;

    const toastSaved = document.getElementById("categorySavedToast") ? new bootstrap.Toast(document.getElementById("categorySavedToast")) : null;
    const toastUpdated = document.getElementById("categoryUpdatedToast") ? new bootstrap.Toast(document.getElementById("categoryUpdatedToast")) : null;
    const toastDeleted = document.getElementById("categoryDeletedToast") ? new bootstrap.Toast(document.getElementById("categoryDeletedToast")) : null;

    const createUrl = document.getElementById("categoryCreateUrl")?.value || "";
    const updateBaseUrl = document.getElementById("categoryUpdateBaseUrl")?.value || "";
    const deleteBaseUrl = document.getElementById("categoryDeleteBaseUrl")?.value || "";
    const saveBudgetUrl = document.getElementById("categorySaveBudgetUrl")?.value || "";
    const budgetsByCategoryUrl = document.getElementById("categoryBudgetsByCategoryUrl")?.value || "";

    const state = {
        currentCategory: null,
        budgets: [],
        activeBudgetId: null,
        defaultIcon: document.querySelector(".category-icon-option-detail")?.dataset.icon || document.getElementById("detailHeadIcon")?.getAttribute("src") || ""
    };

    function currency(value) {
        return Number(value || 0).toLocaleString("vi-VN") + " đ";
    }

    function parseBudgetAmount(rawValue) {
        const normalized = String(rawValue || "").trim().replace(/\s/g, "").replace(/,/g, "");
        if (!normalized) return NaN;
        return Number(normalized);
    }

    function hexToRgba(hex, alpha) {
        if (!hex || !hex.startsWith("#") || hex.length !== 7) return `rgba(255,171,0,${alpha})`;
        const r = parseInt(hex.slice(1, 3), 16);
        const g = parseInt(hex.slice(3, 5), 16);
        const b = parseInt(hex.slice(5, 7), 16);
        return `rgba(${r}, ${g}, ${b}, ${alpha})`;
    }

    function setActiveColor(selector, color) {
        document.querySelectorAll(selector).forEach(function (btn) {
            btn.classList.toggle("active", (btn.dataset.color || "").toUpperCase() === (color || "").toUpperCase());
        });
    }

    function buildUpdateUrl(id) {
        return updateBaseUrl.replace("__id__", encodeURIComponent(id));
    }

    function buildDeleteUrl(id) {
        return deleteBaseUrl.replace("__id__", encodeURIComponent(id));
    }

    function buildCategoryBudgetsUrl(categoryId) {
        const connector = budgetsByCategoryUrl.includes("?") ? "&" : "?";
        return `${budgetsByCategoryUrl}${connector}categoryId=${encodeURIComponent(categoryId)}`;
    }

    async function sendJson(url, method, payload) {
        const response = await fetch(url, {
            method,
            headers: {
                "Content-Type": "application/json",
                "X-Requested-With": "XMLHttpRequest"
            },
            body: payload ? JSON.stringify(payload) : null
        });

        const raw = await response.text();
        let data = null;
        if (raw) {
            try {
                data = JSON.parse(raw);
            } catch {
                data = { message: raw };
            }
        }

        if (!response.ok) {
            throw new Error(data?.message || raw || "Request failed.");
        }

        return data || {};
    }

    async function fetchJson(url) {
        const response = await fetch(url, {
            headers: {
                "X-Requested-With": "XMLHttpRequest"
            }
        });

        const raw = await response.text();
        let data = null;
        if (raw) {
            try {
                data = JSON.parse(raw);
            } catch {
                data = { message: raw };
            }
        }

        if (!response.ok) {
            throw new Error(data?.message || raw || "Request failed.");
        }

        return data || {};
    }

    function formatDate(raw) {
        if (!raw) return "--";
        const d = new Date(raw);
        if (Number.isNaN(d.getTime())) return raw;
        return d.toLocaleDateString("vi-VN");
    }

    function formatDateFromObj(dateObj) {
        return new Date(dateObj).toLocaleDateString("vi-VN", { timeZone: "UTC" });
    }

    function getWeekNumber(dateObj) {
        const date = new Date(Date.UTC(dateObj.getFullYear(), dateObj.getMonth(), dateObj.getDate()));
        const dayNum = date.getUTCDay() || 7;
        date.setUTCDate(date.getUTCDate() + 4 - dayNum);
        const yearStart = new Date(Date.UTC(date.getUTCFullYear(), 0, 1));
        return Math.ceil((((date - yearStart) / 86400000) + 1) / 7);
    }

    function getIsoWeekStartDate(year, week) {
        const jan4 = new Date(Date.UTC(year, 0, 4));
        const jan4Day = jan4.getUTCDay() || 7;
        const firstMonday = new Date(jan4);
        firstMonday.setUTCDate(jan4.getUTCDate() - (jan4Day - 1));
        const start = new Date(firstMonday);
        start.setUTCDate(firstMonday.getUTCDate() + ((week - 1) * 7));
        return start;
    }

    function periodLabel(periodType) {
        switch ((periodType || "").toLowerCase()) {
            case "week": return "Theo tuần";
            case "month": return "Theo tháng";
            case "year": return "Theo năm";
            default: return "Theo tháng";
        }
    }

    function periodShortLabel(item) {
        if (!item) return "";
        if (item.period_type === "week") return `Tuần ${item.period_week}/${item.period_year}`;
        if (item.period_type === "month") return `Tháng ${item.period_month}/${item.period_year}`;
        return `Năm ${item.period_year}`;
    }

    function sortBudgets(items) {
        const rank = { week: 0, month: 1, year: 2 };
        return [...(items || [])].sort(function (a, b) {
            const yearDiff = (b.period_year || 0) - (a.period_year || 0);
            if (yearDiff !== 0) return yearDiff;
            const rankDiff = (rank[a.period_type] ?? 9) - (rank[b.period_type] ?? 9);
            if (rankDiff !== 0) return rankDiff;
            const monthDiff = (b.period_month || 0) - (a.period_month || 0);
            if (monthDiff !== 0) return monthDiff;
            return (b.period_week || 0) - (a.period_week || 0);
        });
    }

    function getPreferredBudget(items) {
        const sorted = sortBudgets(items);
        if (!sorted.length) return null;
        return sorted[0];
    }

    function getDateRangeFromValues(periodType, year, month, week) {
        if (!year || year < 2000) return { start: "--/--/----", end: "--/--/----" };

        if (periodType === "week") {
            const start = getIsoWeekStartDate(year, week || 1);
            const end = new Date(start);
            end.setUTCDate(start.getUTCDate() + 6);
            return { start: formatDateFromObj(start), end: formatDateFromObj(end) };
        }

        if (periodType === "month") {
            const start = new Date(Date.UTC(year, (month || 1) - 1, 1));
            const end = new Date(Date.UTC(year, month || 1, 0));
            return { start: formatDateFromObj(start), end: formatDateFromObj(end) };
        }

        const start = new Date(Date.UTC(year, 0, 1));
        const end = new Date(Date.UTC(year, 11, 31));
        return { start: formatDateFromObj(start), end: formatDateFromObj(end) };
    }

    function getDateRangeFromForm() {
        const periodType = document.getElementById("budgetModalTimeType")?.value || "month";
        const year = parseInt(document.getElementById("budgetModalYear")?.value || "0", 10);
        const month = parseInt(document.getElementById("budgetModalMonth")?.value || "0", 10);
        const week = parseInt(document.getElementById("budgetModalWeek")?.value || "0", 10);
        return getDateRangeFromValues(periodType, year, month, week);
    }

    function updateAddPreview() {
        const color = document.getElementById("addCategoryColor")?.value || "#FFAB00";
        setActiveColor(".category-color-preset", color);
    }

    function updateDetailPreview() {
        const name = document.getElementById("detailCategoryName")?.value || "Danh mục";
        const color = document.getElementById("detailCategoryColor")?.value || "#FFAB00";
        const iconInputValue = document.getElementById("detailCategoryIcon")?.value || "";
        const icon = iconInputValue || state.defaultIcon;

        const headIcon = document.getElementById("detailHeadIcon");
        const headWrap = document.getElementById("detailHeadIconWrap");
        const title = document.getElementById("detailCategoryTitle");
        const budgetText = document.getElementById("budgetCurrentCategoryText");
        const budgetDot = document.getElementById("budgetCurrentColorDot");

        if (title) title.textContent = name;
        if (budgetText) budgetText.textContent = name;
        if (headIcon && icon) headIcon.src = icon;
        if (headWrap) headWrap.style.background = hexToRgba(color, 0.14);
        if (budgetDot) budgetDot.style.background = color;

        setActiveColor(".category-color-preset-detail", color);
        document.querySelectorAll(".category-icon-option-detail").forEach(function (btn) {
            btn.classList.toggle("active", btn.dataset.icon === icon);
        });
    }

    function syncBudgetPeriodPreview() {
        const periodType = document.getElementById("budgetModalTimeType")?.value || "month";
        const monthWrap = document.getElementById("budgetMonthWrap");
        const weekWrap = document.getElementById("budgetWeekWrap");
        const periodBadge = document.getElementById("budgetModalPeriodLabel");
        const periodHint = document.getElementById("budgetModalPeriodHint");
        const range = getDateRangeFromForm();

        if (monthWrap) monthWrap.classList.toggle("d-none", periodType !== "month");
        if (weekWrap) weekWrap.classList.toggle("d-none", periodType !== "week");
        if (periodBadge) periodBadge.textContent = periodLabel(periodType);
        if (periodHint) {
            periodHint.textContent = periodType === "week"
                ? "Mỗi kỳ kéo dài 7 ngày theo chuẩn tuần ISO."
                : periodType === "month"
                    ? "Hệ thống tự lấy ngày đầu và cuối của tháng được chọn."
                    : "Hệ thống tự lấy toàn bộ năm được chọn.";
        }

        const startEl = document.getElementById("budgetModalStartDate");
        const endEl = document.getElementById("budgetModalEndDate");
        if (startEl) startEl.textContent = range.start;
        if (endEl) endEl.textContent = range.end;
    }

    function setBudgetFormToDate(periodType, dateObj) {
        const date = dateObj instanceof Date ? dateObj : new Date();
        const year = date.getFullYear();
        const month = date.getMonth() + 1;
        const week = getWeekNumber(date);

        const typeEl = document.getElementById("budgetModalTimeType");
        const yearEl = document.getElementById("budgetModalYear");
        const monthEl = document.getElementById("budgetModalMonth");
        const weekEl = document.getElementById("budgetModalWeek");

        if (typeEl) typeEl.value = periodType;
        if (yearEl) yearEl.value = year;
        if (monthEl) monthEl.value = month;
        if (weekEl) weekEl.value = week;

        syncBudgetPeriodPreview();
    }

    function fillBudgetForm(budget) {
        const spentEl = document.getElementById("budgetModalSpent");
        const modeBadge = document.getElementById("budgetModalModeBadge");

        document.getElementById("budgetModalBudgetId").value = budget?.budget_id || "";
        document.getElementById("budgetModalAmount").value = budget?.limit_amount ?? "";
        if (spentEl) spentEl.value = currency(budget?.spent_amount ?? 0);
        document.getElementById("budgetModalYear").value = budget?.period_year || new Date().getFullYear();
        document.getElementById("budgetModalMonth").value = budget?.period_month || (new Date().getMonth() + 1);
        document.getElementById("budgetModalWeek").value = budget?.period_week || getWeekNumber(new Date());
        document.getElementById("budgetModalTimeType").value = budget?.period_type || "month";

        if (modeBadge) {
            modeBadge.textContent = budget?.budget_id ? "Đang chỉnh sửa" : "Tạo mới";
            modeBadge.className = budget?.budget_id ? "badge bg-label-warning" : "badge bg-label-primary";
        }

        state.activeBudgetId = budget?.budget_id || null;
        syncBudgetPeriodPreview();
        highlightBudgetItem();
    }

    function resetBudgetForm() {
        const spentEl = document.getElementById("budgetModalSpent");
        const amountEl = document.getElementById("budgetModalAmount");
        const modeBadge = document.getElementById("budgetModalModeBadge");

        document.getElementById("budgetModalBudgetId").value = "";
        if (amountEl) amountEl.value = "";
        if (spentEl) spentEl.value = currency(0);
        state.activeBudgetId = null;
        setBudgetFormToDate("month", new Date());

        if (modeBadge) {
            modeBadge.textContent = "Tạo mới";
            modeBadge.className = "badge bg-label-primary";
        }

        highlightBudgetItem();
    }

    function openBudgetChildDialog() {
        const overlay = document.getElementById("budgetChildOverlay");
        if (!overlay) return;

        overlay.classList.remove("d-none");
        overlay.setAttribute("aria-hidden", "false");
        document.body.classList.add("category-subdialog-open");

        window.setTimeout(function () {
            document.getElementById("budgetModalAmount")?.focus();
        }, 30);
    }

    function closeBudgetChildDialog() {
        const overlay = document.getElementById("budgetChildOverlay");
        if (!overlay) return;

        overlay.classList.add("d-none");
        overlay.setAttribute("aria-hidden", "true");
        document.body.classList.remove("category-subdialog-open");
    }

    function revealBudgetEditor(resetToNew) {
        if (resetToNew) {
            resetBudgetForm();
        }
        openBudgetChildDialog();
    }

    function highlightBudgetItem() {
        document.querySelectorAll(".category-budget-tile").forEach(function (item) {
            item.classList.toggle("active", item.dataset.budgetId === state.activeBudgetId);
        });
    }

    function renderBudgetList(items) {
        const grid = document.getElementById("detailBudgetList");
        const countBadge = document.getElementById("budgetModalListCount");
        const sorted = sortBudgets(items);

        if (countBadge) {
            countBadge.textContent = `${sorted.length} mục`;
        }

        if (!grid) return;

        if (!sorted.length) {
            grid.innerHTML = "";
            highlightBudgetItem();
            return;
        }

        const preferred = getPreferredBudget(sorted);
        const preferredId = preferred?.budget_id || null;

        grid.innerHTML = sorted.map(function (item) {
            const spent = Number(item.spent_amount || 0);
            const total = Number(item.limit_amount || 0);
            const percentage = Number(item.percentage_used || 0);
            const progress = Math.min(Math.max(percentage, 0), 100);

            const statusClass =
                item.status === "over" ? "is-over" :
                item.status === "reached" ? "is-reached" :
                "is-normal";

            const preferredChip = item.budget_id === preferredId
                ? `<span class="category-budget-tile__preferred">Ưu tiên ngoài card</span>`
                : "";

            const statusText =
                item.status === "over" ? "Đang vượt mức" :
                item.status === "reached" ? "Đã chạm hạn mức" :
                "Đang trong mức";

            const progressClass =
                item.status === "over" ? "bg-danger" :
                item.status === "reached" ? "bg-warning" :
                "bg-primary";

            return `
                <button type="button" class="category-budget-tile ${statusClass}" data-budget-id="${item.budget_id}">
                    ${preferredChip}
                    <div class="category-budget-tile__header">
                        <div>
                            <div class="category-budget-tile__title">${periodShortLabel(item)}</div>
                            <div class="category-budget-tile__date">${formatDate(item.start_date)} - ${formatDate(item.end_date)}</div>
                        </div>
                        <span class="badge bg-label-secondary">${periodLabel(item.period_type)}</span>
                    </div>

                    <div class="category-budget-tile__amount">${currency(spent)} / ${currency(total)}</div>

                    <div class="progress category-budget-tile__progress">
                        <div class="progress-bar ${progressClass}" style="width:${progress}%"></div>
                    </div>

                    <div class="category-budget-tile__footer">
                        <span>${statusText}</span>
                        <strong>${percentage.toFixed(1)}%</strong>
                    </div>
                </button>
            `;
        }).join("");

        grid.querySelectorAll(".category-budget-tile").forEach(function (button) {
            button.addEventListener("click", function () {
                const budgetId = button.dataset.budgetId || "";
                const budget = state.budgets.find(function (item) {
                    return item.budget_id === budgetId;
                });

                if (budget) {
                    fillBudgetForm(budget);
                    openBudgetChildDialog();
                }
            });
        });

        highlightBudgetItem();
    }

    function renderDetailBudgetSummary() {
        const noBudgetState = document.getElementById("noBudgetState");
        const hasBudgetState = document.getElementById("hasBudgetState");
        const hasItems = Array.isArray(state.budgets) && state.budgets.length > 0;

        noBudgetState?.classList.toggle("d-none", hasItems);
        hasBudgetState?.classList.toggle("d-none", !hasItems);
    }

    async function loadBudgetsForCurrentCategory() {
        if (!state.currentCategory?.id) return;
        const response = await fetchJson(buildCategoryBudgetsUrl(state.currentCategory.id));
        state.budgets = Array.isArray(response.items) ? response.items : [];
        renderBudgetList(state.budgets);
        renderDetailBudgetSummary();
    }

    function setDetailStateFromTrigger(trigger) {
        const categoryId = trigger.getAttribute("data-category-id") || "";
        const categoryName = trigger.getAttribute("data-category-name") || "Danh mục";
        const categoryColor = trigger.getAttribute("data-category-color") || "#FFAB00";
        const categoryIcon = trigger.getAttribute("data-category-icon") || state.defaultIcon;
        const canEdit = trigger.getAttribute("data-category-can-edit") === "true";
        const canDelete = trigger.getAttribute("data-category-can-delete") === "true";
        const isDefault = trigger.getAttribute("data-category-is-default") === "true";

        state.currentCategory = { id: categoryId, name: categoryName, color: categoryColor, icon: categoryIcon };

        document.getElementById("detailCategoryId").textContent = categoryId;
        document.getElementById("detailCategoryName").value = categoryName;
        document.getElementById("detailCategoryColor").value = categoryColor;
        document.getElementById("detailCategoryIcon").value = categoryIcon || state.defaultIcon;
        document.getElementById("detailCategoryCanEdit").value = canEdit ? "true" : "false";
        document.getElementById("detailCategoryCanDelete").value = canDelete ? "true" : "false";

        const typeBadge = document.getElementById("detailCategoryTypeBadge");
        if (typeBadge) {
            typeBadge.textContent = isDefault ? "Mặc định" : "Tùy chỉnh";
            typeBadge.className = isDefault ? "badge bg-label-secondary" : "badge bg-label-primary";
        }

        const deleteButton = document.getElementById("btnDeleteCategoryStatic");
        const updateButton = document.getElementById("btnUpdateCategoryStatic");
        const detailNameInput = document.getElementById("detailCategoryName");
        const detailColorInput = document.getElementById("detailCategoryColor");

        if (deleteButton) deleteButton.disabled = !canDelete;
        if (updateButton) updateButton.disabled = !canEdit;
        if (detailNameInput) detailNameInput.readOnly = !canEdit;
        if (detailColorInput) detailColorInput.disabled = !canEdit;

        document.querySelectorAll(".category-color-preset-detail, .category-icon-option-detail").forEach(function (el) {
            if (!canEdit) {
                el.classList.add("disabled");
                el.style.pointerEvents = "none";
                el.style.opacity = "0.65";
            } else {
                el.classList.remove("disabled");
                el.style.pointerEvents = "";
                el.style.opacity = "";
            }
        });

        updateDetailPreview();
        resetBudgetForm();
    }

    document.querySelectorAll(".category-color-preset").forEach(function (btn) {
        btn.addEventListener("click", function () {
            const color = btn.dataset.color || "#FFAB00";
            const input = document.getElementById("addCategoryColor");
            if (input) input.value = color;
            updateAddPreview();
        });
    });

    document.querySelectorAll(".category-color-preset-detail").forEach(function (btn) {
        btn.addEventListener("click", function () {
            const color = btn.dataset.color || "#FFAB00";
            const input = document.getElementById("detailCategoryColor");
            if (input) input.value = color;
            updateDetailPreview();
        });
    });

    document.querySelectorAll(".category-icon-option-add").forEach(function (btn) {
        btn.addEventListener("click", function () {
            document.querySelectorAll(".category-icon-option-add").forEach(function (item) { item.classList.remove("active"); });
            btn.classList.add("active");
            const iconInput = document.getElementById("addCategoryIcon");
            if (iconInput) iconInput.value = btn.dataset.icon || "";
        });
    });

    document.querySelectorAll(".category-icon-option-detail").forEach(function (btn) {
        btn.addEventListener("click", function () {
            if (document.getElementById("detailCategoryCanEdit")?.value !== "true") return;
            document.querySelectorAll(".category-icon-option-detail").forEach(function (item) { item.classList.remove("active"); });
            btn.classList.add("active");
            const iconInput = document.getElementById("detailCategoryIcon");
            if (iconInput) iconInput.value = btn.dataset.icon || "";
            updateDetailPreview();
        });
    });

    ["addCategoryColor"].forEach(function (id) {
        const el = document.getElementById(id);
        if (el) el.addEventListener("input", updateAddPreview);
    });

    ["detailCategoryName", "detailCategoryColor"].forEach(function (id) {
        const el = document.getElementById(id);
        if (el) el.addEventListener("input", updateDetailPreview);
    });

    ["budgetModalTimeType", "budgetModalYear", "budgetModalMonth", "budgetModalWeek"].forEach(function (id) {
        const el = document.getElementById(id);
        if (!el) return;
        el.addEventListener("input", syncBudgetPeriodPreview);
        el.addEventListener("change", syncBudgetPeriodPreview);
    });

    document.querySelectorAll("[data-budget-shortcut]").forEach(function (btn) {
        btn.addEventListener("click", function () {
            const shortcut = btn.dataset.budgetShortcut || "current-month";
            const now = new Date();
            if (shortcut === "current-week") {
                setBudgetFormToDate("week", now);
            } else if (shortcut === "current-month") {
                setBudgetFormToDate("month", now);
            } else if (shortcut === "current-year") {
                setBudgetFormToDate("year", now);
            } else if (shortcut === "next-month") {
                setBudgetFormToDate("month", new Date(now.getFullYear(), now.getMonth() + 1, 1));
            }
            revealBudgetEditor(false);
        });
    });
    document.getElementById("btnOpenBudgetEditor")?.addEventListener("click", function () {
        revealBudgetEditor(true);
    });

    document.getElementById("btnCreateNewBudgetEntry")?.addEventListener("click", function () {
        resetBudgetForm();
    });

    document.getElementById("btnCloseBudgetChild")?.addEventListener("click", function () {
        closeBudgetChildDialog();
    });

    document.querySelectorAll("[data-budget-overlay-close='true']").forEach(function (el) {
        el.addEventListener("click", function () {
            closeBudgetChildDialog();
        });
    });

    const btnSave = document.getElementById("btnSaveCategoryStatic");
    if (btnSave) {
        btnSave.addEventListener("click", async function () {
            const categoryName = (document.getElementById("addCategoryName")?.value || "").trim();
            const color = document.getElementById("addCategoryColor")?.value || "#FFAB00";
            const icon = document.getElementById("addCategoryIcon")?.value || "";

            if (!categoryName) {
                alert("Vui lòng nhập tên danh mục.");
                return;
            }

            btnSave.disabled = true;
            try {
                await sendJson(createUrl, "POST", { category_name: categoryName, color, icon });
                addModal?.hide();
                toastSaved?.show();
                setTimeout(function () { window.location.reload(); }, 700);
            } catch (error) {
                alert(error.message || "Tạo danh mục thất bại.");
            } finally {
                btnSave.disabled = false;
            }
        });
    }

    const btnUpdate = document.getElementById("btnUpdateCategoryStatic");
    if (btnUpdate) {
        btnUpdate.addEventListener("click", async function () {
            if (document.getElementById("detailCategoryCanEdit")?.value !== "true") {
                alert("Danh mục mặc định chỉ có thể xem, không thể chỉnh sửa.");
                return;
            }

            const categoryId = document.getElementById("detailCategoryId")?.textContent || "";
            const categoryName = (document.getElementById("detailCategoryName")?.value || "").trim();
            const color = document.getElementById("detailCategoryColor")?.value || "#FFAB00";
            const icon = document.getElementById("detailCategoryIcon")?.value || state.defaultIcon;

            if (!categoryId || !categoryName) {
                alert("Dữ liệu danh mục chưa hợp lệ.");
                return;
            }

            btnUpdate.disabled = true;
            try {
                await sendJson(buildUpdateUrl(categoryId), "PUT", { category_name: categoryName, color, icon });
                toastUpdated?.show();
                setTimeout(function () { window.location.reload(); }, 700);
            } catch (error) {
                alert(error.message || "Cập nhật danh mục thất bại.");
            } finally {
                btnUpdate.disabled = false;
            }
        });
    }

    const btnDelete = document.getElementById("btnDeleteCategoryStatic");
    if (btnDelete) {
        btnDelete.addEventListener("click", async function () {
            if (document.getElementById("detailCategoryCanDelete")?.value !== "true") {
                alert("Danh mục mặc định không thể xóa.");
                return;
            }

            const categoryId = document.getElementById("detailCategoryId")?.textContent || "";
            const categoryName = document.getElementById("detailCategoryName")?.value || "";
            if (!categoryId) return;

            const confirmed = window.confirm(`Bạn có chắc muốn xóa danh mục "${categoryName}" không? Hệ thống sẽ tự chuyển dữ liệu sang danh mục thay thế phù hợp.`);
            if (!confirmed) return;

            btnDelete.disabled = true;
            try {
                await sendJson(buildDeleteUrl(categoryId), "DELETE");
                detailModal?.hide();
                toastDeleted?.show();
                setTimeout(function () { window.location.reload(); }, 700);
            } catch (error) {
                alert(error.message || "Xóa danh mục thất bại.");
            } finally {
                btnDelete.disabled = false;
            }
        });
    }

    const btnSaveBudget = document.getElementById("btnSaveBudget");
    if (btnSaveBudget) {
        btnSaveBudget.addEventListener("click", async function () {
            const categoryId = (document.getElementById("detailCategoryId")?.textContent || "").trim();
            const budgetId = document.getElementById("budgetModalBudgetId")?.value || "";
            const periodType = document.getElementById("budgetModalTimeType")?.value || "month";
            const amount = parseBudgetAmount(document.getElementById("budgetModalAmount")?.value || "");
            const year = parseInt(document.getElementById("budgetModalYear")?.value || "0", 10);
            const month = periodType === "month" ? parseInt(document.getElementById("budgetModalMonth")?.value || "0", 10) : null;
            const week = periodType === "week" ? parseInt(document.getElementById("budgetModalWeek")?.value || "0", 10) : null;

            if (!categoryId || !Number.isFinite(amount) || amount <= 0 || !year) {
                alert("Vui lòng nhập hạn mức hợp lệ.");
                return;
            }
            if (periodType === "month" && (!month || month < 1 || month > 12)) {
                alert("Vui lòng chọn tháng hợp lệ.");
                return;
            }
            if (periodType === "week" && (!week || week < 1 || week > 53)) {
                alert("Vui lòng chọn tuần ISO hợp lệ.");
                return;
            }

            btnSaveBudget.disabled = true;
            try {
                await sendJson(saveBudgetUrl, "POST", {
                    category_id: categoryId,
                    budget_id: budgetId || null,
                    period_type: periodType,
                    period_year: year,
                    period_month: month,
                    period_week: week,
                    limit_amount: amount
                });

                await loadBudgetsForCurrentCategory();
                const savedBudget = state.budgets.find(function (item) {
                    return item.period_type === periodType
                        && Number(item.period_year || 0) === year
                        && Number(item.period_month || 0) === Number(month || 0)
                        && Number(item.period_week || 0) === Number(week || 0);
                });

                if (savedBudget) {
                    fillBudgetForm(savedBudget);
                } else {
                    resetBudgetForm();
                }

                toastSaved?.show();
                closeBudgetChildDialog();
            } catch (error) {
                alert(error.message || "Lưu hạn mức thất bại.");
            } finally {
                btnSaveBudget.disabled = false;
            }
        });
    }

    if (detailModalEl) {
        detailModalEl.addEventListener("show.bs.modal", async function (event) {
            const trigger = event.relatedTarget;
            if (!trigger) return;
            setDetailStateFromTrigger(trigger);
            await loadBudgetsForCurrentCategory();
        });

        detailModalEl.addEventListener("hidden.bs.modal", function () {
            state.currentCategory = null;
            state.budgets = [];
            state.activeBudgetId = null;
            closeBudgetChildDialog();
        });
    }

    updateAddPreview();
    updateDetailPreview();
    resetBudgetForm();
});
